package br.com.forum.forum.controllers;

import br.com.forum.forum.entitys.Topico;
import br.com.forum.forum.repositorys.TopicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TopicosController {

    @Autowired
    private TopicoRepository topicoRepository;

    @RequestMapping("/topicos")
    public List<Topico> topicos(){
        return topicoRepository.findAll();
    }

}
