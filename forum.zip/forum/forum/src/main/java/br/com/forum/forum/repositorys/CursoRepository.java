package br.com.forum.forum.repositorys;

import br.com.forum.forum.entitys.Curso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CursoRepository extends JpaRepository<Curso, Long> {
    Curso findByNome(String nome);
}
