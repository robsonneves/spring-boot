package br.com.forum.forum.entitys;

public enum StatusTopico {

    NAO_RESPONDIDO,
    NAO_SOLUCIONADO,
    SOLUCIONADO,
    FECHADO;

}
