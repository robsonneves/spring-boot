package br.com.forum.forum.forms;

import br.com.forum.forum.entitys.Curso;
import br.com.forum.forum.entitys.Topico;
import br.com.forum.forum.repositorys.CursoRepository;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class TopicoForm {

    @NotNull @NotEmpty
    private String titulo;
    @NotNull @NotEmpty
    private String mensagem;
    @NotNull @NotEmpty @Max(20)
    private String nomeCurso;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public String getCurso() {
        return nomeCurso;
    }

    public void setCurso(String curso) {
        this.nomeCurso = curso;
    }

    public Topico converter(CursoRepository cursoRepository){
        Curso curso = cursoRepository.findByNome(nomeCurso);
        Topico topico = new Topico(titulo, mensagem, curso);
        return topico;
    }

}
